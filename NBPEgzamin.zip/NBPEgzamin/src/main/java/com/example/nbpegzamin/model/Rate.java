package com.example.nbpegzamin.model;

public class Rate {
    public String Currency;
    public String Code;
    public double Mid;
}