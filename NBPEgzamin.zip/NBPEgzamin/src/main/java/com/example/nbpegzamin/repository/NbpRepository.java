package com.example.nbpegzamin.repository;

import com.example.nbpegzamin.model.DatabaseEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//Repository - interfejs do wykonywania operacji na bazie danych. Klasa (Entity, Encja to DatabaseEntry) a typem ID w tej klasie jest integer
//JpaRepository<Encja, typId>
@Repository
public interface NbpRepository extends JpaRepository<DatabaseEntry, Integer> {
}
