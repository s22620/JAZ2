package com.example.nbpegzamin.model;

//Klasa ktora podajemy jako requestbody w kontrolerze, zawiera tylko dwa pola z datami
public class RateDates {
    private String dateFrom;
    private String dateTo;

    public RateDates(String dateFrom, String dateTo) {
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }
}
