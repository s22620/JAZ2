package com.example.nbpegzamin.model;


import java.util.Date;
import java.util.List;

public class ExchangeRatesTable {
    public String Table;
    public String No;
    public Date EffectiveDate;
    public List<Rate> Rates;
}
