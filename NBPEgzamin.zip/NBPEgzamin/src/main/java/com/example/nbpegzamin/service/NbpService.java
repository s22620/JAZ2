package com.example.nbpegzamin.service;

import com.example.nbpegzamin.model.ExchangeRatesTable;
import com.example.nbpegzamin.repository.NbpRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

@Service
public class NbpService {

    //Wstrzyknięcie customowego bean'a
    private final RestTemplate restTemplate;
    //Wstrzyknięcie Bean'a repository
    private final NbpRepository nbpRepository;

    public NbpService(RestTemplate restTemplate, NbpRepository nbpRepository) {
        this.restTemplate = restTemplate;
        this.nbpRepository = nbpRepository;
    }

    public List<ExchangeRatesTable> getRates(String startDate, String endDate, String currency) {
        ResponseEntity<ExchangeRatesTable> response = restTemplate
                .getForEntity(getUrl(startDate, endDate, currency), ExchangeRatesTable.class);
        if (response.getStatusCode() != HttpStatus.OK) {
            throw new ResponseStatusException(response.getStatusCode());
        }
        ExchangeRatesTable nbp = response.getBody();

        double avg = countAvgCurrency(nbp);

        DatabaseEntry databaseEntry = new DatabaseEntry();
        databaseEntry.setWalute(currency);
        databaseEntry.setWynik(avg);
        databaseEntry.setDate_start(startDate);
        databaseEntry.setDate_end(endDate);
        //LocalDate.now().getYear()
        databaseEntry.setData_zapisu(LocalDate.now().toString());
        nbpRepository.save(databaseEntry);

        return avg;
    }


    //https://api.nbp.pl/api/exchangerates/rates/a/gbp/2012-01-01/2012-01-02/
    private String getUrl(String startDate, String endDate, String currency) {
        return "https://api.nbp.pl/api/exchangerates/rates/a/" + currency + "/" + startDate + "/" + endDate + "/";
    }
}
