package com.example.nbpegzamin.service;

import com.example.nbpegzamin.model.DatabaseEntry;
import com.example.nbpegzamin.model.Rate;
import com.example.nbpegzamin.model.Root;
import com.example.nbpegzamin.repository.NbpRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class NbpService {

    //Wstrzyknięcie customowego bean'a
    private final RestTemplate restTemplate;
    //Wstrzyknięcie Bean'a repository
    private final NbpRepository nbpRepository;

    public NbpService(RestTemplate restTemplate, NbpRepository nbpRepository) {
        this.restTemplate = restTemplate;
        this.nbpRepository = nbpRepository;
    }

    public List<Rate> getRates(String startDate, String endDate, String currency) {
        //ResponseEntity<Root[]> - znaczy że oczekujemy od NBP obiektu który będzie tablicą takich elementów,
        // tak samo w przypadku metody getForEntity, tam również podajemy typ obiektu który oczekujemy że zostanie zwrócony oraz url z którego pobierzemy obiekt
        ResponseEntity<Root[]> response = restTemplate
                .getForEntity(getUrl(startDate, endDate), Root[].class);
        //Sprawdzamy czy rządanie zakończyło się sukcesem - jeżeli odpowiedź, status HTTP to 200/OK to znaczy że tak, w przeciwnym przypadku rzucamy wyjątek
        if (response.getStatusCode() != HttpStatus.OK) {
            throw new ResponseStatusException(response.getStatusCode());
        }
        //Pobieramy "Body", czyli ciało odpowiedzi od npb. W tym przypadku jest to tablica obiektów Root[]
        Root[] nbp = response.getBody();

        List<Rate> rates = getRates(nbp, currency);

        //Utworzenie obiektu który zostanie zapisany do bazy danych oraz przypisanie mu wartości:
        DatabaseEntry databaseEntry = new DatabaseEntry();
        databaseEntry.setCurrency(currency);
        databaseEntry.setDateFrom(startDate);
        databaseEntry.setDateEnd(endDate);
        databaseEntry.setCountOfRecords(rates.size());
        //LocalDate.now().getYear()
        databaseEntry.setDateSave(LocalDate.now().toString());
        //Zapis obiektu do bazy danych
        nbpRepository.save(databaseEntry);

        return rates;
    }

    ///Metoda która przechodzi po otrzymanych obiektach z nbp (Przykladowa odpowiedz w pliku o nazwie odpowiedz.txt).
    //Wyciągamy z każdego obiektu "Root" odpowowiadające mu rate, następnie przechodzimy po wszystkich rate'ach i sprawdzamy czy waluta jest taka sama jak nasza
    private List<Rate> getRates(Root[] roots, String currency) {
        List<Rate> result = new ArrayList<>();
        for (Root root : roots) {
            for (Rate rate : root.getRates()) {
                if (rate.getCode().equals(currency)) {
                    result.add(rate);
                }
            }
        }
        return result;
    }

    //Metoda od uzyskania endpointu, do którego będziemy "strzelać" po dane. Podstawiamy tutaj wybrane daty.
    //https://http://api.nbp.pl/api/exchangerates/tables/a/2012-01-01/2012-01-02/
    private String getUrl(String startDate, String endDate) {
        return "https://api.nbp.pl/api/exchangerates/tables/a/" + startDate + "/" + endDate + "/";
    }
}
