package com.example.nbpegzamin.controller;

import com.example.nbpegzamin.model.ExchangeRatesTable;
import com.example.nbpegzamin.service.NbpService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/nbp")
@RestController
public class NbpController {

    private final NbpService nbpService;

    public NbpController(NbpService nbpService) {
        this.nbpService = nbpService;
    }

    @PostMapping("/{currency}")
    public ResponseEntity<List<ExchangeRatesTable>> nbpEndpoint(@PathVariable String currency,
                                                                @RequestBody String dateFrom,
                                                                @RequestBody String dateTo){
        return ResponseEntity.status(200).body(nbpService.getRates(currency,dateFrom,dateFrom));
    }
}
