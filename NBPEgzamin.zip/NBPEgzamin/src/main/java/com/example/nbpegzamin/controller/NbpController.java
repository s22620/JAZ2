package com.example.nbpegzamin.controller;

import com.example.nbpegzamin.model.Rate;
import com.example.nbpegzamin.model.RateDates;
import com.example.nbpegzamin.service.NbpService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//kontroler dostępny pod adresem localhost:8080/nbp
//Link do swaggera: http://localhost:8080/swagger-ui/index.html#/
@RequestMapping("/nbp")
@RestController
public class NbpController {

    private final NbpService nbpService;

    public NbpController(NbpService nbpService) {
        this.nbpService = nbpService;
    }

    @PostMapping("/{currency}")
    @Operation(description = "Program pobiera rate dla danej waluty z tabeli a")
    @ApiResponses({@ApiResponse(responseCode = "404", description = "404 Not Found"),
            @ApiResponse(responseCode = "400", description = "400 Bad Request")})
    //@RequestBody - przekazujemy obiekt w formacie json do endpoin'tu
    //przykladowe rzadanie: 'http://localhost:8080/nbp/GBP' , rateDates są jako obiekt
    public ResponseEntity<List<Rate>> nbpEndpoint(@PathVariable String currency,
                                                  @RequestBody RateDates rateDates) {
        return ResponseEntity.status(200).body(nbpService.getRates(rateDates.getDateFrom(), rateDates.getDateTo(), currency));
    }
}
