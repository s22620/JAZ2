package com.example.nbpegzamin.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;


//Klasa definiujaca format tabeli w bazie danych, na jej podstawie zostanie utworzona tabela z polami, takimi jak kolumny
//Wymagane: @Entity,@Id, Getter And Setter
@Entity
//nazwa tabeli w bazie danych
@Table(name = "rates")
public class DatabaseEntry {

    public DatabaseEntry() {

    }

    public DatabaseEntry(Integer id, String currency, String dateFrom, String dateEnd, String dateSave, Integer countOfRecords) {
        this.id = id;
        this.currency = currency;
        this.dateFrom = dateFrom;
        this.dateEnd = dateEnd;
        this.dateSave = dateSave;
        this.countOfRecords = countOfRecords;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    //@Column -> oznacza kolumne w bazie
    @Column(name = "CURRENCY")
    private String currency;

    //****Potencjalnie może być do zmiany, na ten moment wystarczy
    @Column(name = "DATE_START")
    @Schema(name = "Title", description = "Początkowa data")
    private String dateFrom;
    @Column(name = "DATE_END")
    @Schema(name = "Title", description = "Końcowa data")
    private String dateEnd;
    @Column(name = "DATE_SAVE")
    @Schema(name = "Title", description = "Data zapisu")
    private String dateSave;
    @Column(name = "COUNT_OF_RECORDS")
    @Schema(name = "Title", description = "Data zapisu")
    private Integer countOfRecords;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(String dateEnd) {
        this.dateEnd = dateEnd;
    }

    public String getDateSave() {
        return dateSave;
    }

    public void setDateSave(String dateSave) {
        this.dateSave = dateSave;
    }

    public Integer getCountOfRecords() {
        return countOfRecords;
    }

    public void setCountOfRecords(Integer countOfRecords) {
        this.countOfRecords = countOfRecords;
    }

    @Override
    public String toString() {
        return "DatabaseEntry{" +
                "id=" + id +
                ", currency='" + currency + '\'' +
                ", dateFrom='" + dateFrom + '\'' +
                ", dateEnd='" + dateEnd + '\'' +
                ", dateSave='" + dateSave + '\'' +
                ", countOfRecords=" + countOfRecords +
                '}';
    }
}

