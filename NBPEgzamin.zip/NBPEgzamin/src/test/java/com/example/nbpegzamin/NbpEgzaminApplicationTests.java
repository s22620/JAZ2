package com.example.nbpegzamin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NbpEgzaminApplicationTests {

    @Test
    void contextLoads() {
    }

}
